import GameEvent from '../GameEvent.js'

export default class Hero extends GameEvent{
    constructor(name,icoUrl){
        super();
        this.name = name;
        this.ico = icoUrl;
        // 绑定自定义事件
        
        this.addEvent("myinit",this.init);
        // this.removeEvent("myinit",this.init)  //第一种移除自定义方法
        // this.removeEvent("myinit")    // 第二种移除自定义的方法
    }
    init(){
        console.log("初始化英雄逻辑");
    }
}