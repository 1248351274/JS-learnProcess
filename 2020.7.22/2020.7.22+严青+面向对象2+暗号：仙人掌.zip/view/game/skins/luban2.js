export default class Luban2{
    constructor(){
        this.name = "皮肤二";
        this.ico = "./sources/heros/luban2.png";
        this.img = "./sources/skins/301121.png";
    }
}