export default class GameEvnet {
    constructor() {
        this.handle = {};
    }
    // 添加事件
    addEvent(eventName, fn) {
        if (typeof this.handle[eventName] === 'undefined') {
            this.handle[eventName] = [];
        }
        this.handle[eventName].push(fn);
    }
    // 触发事件
    trigger(eventName) {
        if (typeof this.handle[eventName] === 'undefined') {
            return;
        }
        this.handle[eventName].forEach(fn => {
            fn();
        })
    }
    // 移除自定义事件

    // 第一种：移除handle中的某个方法，需要两个变量,只能在添加事件页面调用
    // 此处在hero.js中调用
    // removeEvent1(eventName,fn){
    //     if (typeof this.handle[eventName] === undefined) {
    //         return;
    //     }
    //     console.log('this.handle1',this.handle)
    //     this.handle[eventName].forEach((fn,index) => {
    //         this.handle[eventName].splice(index,1)
    //     })
    //     console.log('this.handle2',this.handle)
    // }
    
    // 第二种：通过移除事件名称，移除
    // 可以在hero.js或者game.js,任意能访问到GameEvent.js的js中调用
    // 我倾向于第二种
    removeEvent(eventName){
        if (typeof this.handle[eventName] === undefined) {
            return;
        }
        console.log('this.handle1',this.handle)
        delete this.handle[eventName]
        console.log('this.handle2',this.handle)
    }
}

// let newmyevent = new GameEvnet();
// newmyevent.addEvent("myevnet",fn1);
// newmyevent.addEvent("myevnet",fn2);
// newmyevent.removeEvent("myevnet",fn1);
// newmyevent.trigger("myevnet")